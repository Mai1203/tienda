import React from 'react'

const ThemeSettings = () => {
  return (
    <div>ThemeSettings</div>
  )
}

export default ThemeSettings