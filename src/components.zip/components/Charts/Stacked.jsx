import React from 'react'

const Stacked = () => {
  return (
    <div>Stacked</div>
  )
}

export default Stacked