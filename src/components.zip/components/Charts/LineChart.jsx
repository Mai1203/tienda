import React from 'react'

const LineChart = () => {
  return (
    <div>LineChart</div>
  )
}

export default LineChart