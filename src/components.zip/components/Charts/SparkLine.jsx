import React from 'react'

const SparkLine = () => {
  return (
    <div>SparkLine</div>
  )
}

export default SparkLine